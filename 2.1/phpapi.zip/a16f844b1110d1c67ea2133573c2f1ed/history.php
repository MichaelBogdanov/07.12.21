<?php
$servername = "localhost";
$database = "lordprs0_test";
$username = "lordprs0_test";
$password = "P@ssw0rd";
// Создаем соединение
$conn = mysqli_connect($servername, $username, $password, $database);
// Проверяем соединение
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$result = $conn->query("SELECT * FROM zap ORDER BY id ASC");
foreach ($result as $row) {
    echo $row['id'].';'.$row['date'].';'.$row['unit'].';'.$row['rez'].';'.$row['user'].';'.$row['garage'].'|';
}

?>