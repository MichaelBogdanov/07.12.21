<?php
$servername = "localhost";
$database = "lordprs0_test";
$username = "lordprs0_test";
$password = "P@ssw0rd";
// Создаем соединение
$conn = mysqli_connect($servername, $username, $password, $database);
// Проверяем соединение
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
//echo "SELECT * FROM detect WHERE name ='".$_GET["name"]."';";
$result = $conn->query("SELECT * FROM detect WHERE name ='".$_GET['name']."';");
foreach ($result as $row) {
    echo $row['id'].';'.$row['date'].';'.$row['name'].'|';
}

?>