<?php
$servername = "localhost";
$database = "lordprs0_test";
$username = "lordprs0_test";
$password = "P@ssw0rd";
// Создаем соединение
$conn = mysqli_connect($servername, $username, $password, $database);
// Проверяем соединение
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$conn->query("INSERT INTO `detect` (`id`, `date`, `name`) VALUES (NULL, SYSDATE(), '".$_GET["name"]."');");
echo "Данные успешно добавленны";
mysqli_close($conn);

?>