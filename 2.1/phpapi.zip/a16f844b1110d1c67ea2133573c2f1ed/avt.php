<?php
$servername = "localhost";
$database = "lordprs0_test";
$username = "lordprs0_test";
$password = "P@ssw0rd";
// Создаем соединение
$conn = mysqli_connect($servername, $username, $password, $database);
// Проверяем соединение
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$result = $conn->query("SELECT * FROM users WHERE log ='".$_GET['log']."'and pass ='".$_GET['pass']."'"  );
foreach ($result as $row) {
    echo $row['log'];
}

?>