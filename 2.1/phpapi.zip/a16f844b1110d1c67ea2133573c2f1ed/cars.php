<?php
$fp = fopen("cars_loc.php", "w "); 
$mytext = "<?php echo '".$_GET["cord"]."';?>"; 
$test = fwrite($fp, $mytext); 
if ($test) echo 'Данные в файл успешно занесены.';
else echo 'Ошибка при записи в файл.';
fclose($fp); 
/*
$fp = file("ip.txt");
echo $fr;
if($fp <> "")
{
    if($_SERVER['ip'] == $_SERVER['HTTP_HOST'])
    {
        $fp = fopen("cars_loc.php", "w "); // Открываем файл в режиме записи
        $mytext = "<?php echo '".$_GET["cord"]."';?>"; // Исходная строка
        $test = fwrite($fp, $mytext); // Запись в файл
        if ($test) echo 'Данные в файл успешно занесены.';
        else echo 'Ошибка при записи в файл.';
        fclose($fp); //Закрытие файла
        setcookie('ip',  $_SERVER['HTTP_HOST'] , time() + (60));
    }
    else
    {
        echo "go away users";
    }
}
else
{
     $fp = fopen("ip.php", "w ");
     $test = fwrite($fp, isset($_SERVER['ip']));
     fclose($fp);
}*/
?>