<?php
if(isset($GET_["x"]) && isset($GET_["y"]))
{


}
else
{
    $filepath_ip = '../static/ip_cli.txt';
    $filepath_coord = '../static/car_coord.txt';

    $ip_client = $_SERVER['HTTP_HOST'];
    if(filesize($filepath_ip) == 0 || (strtotime(date('Y-m-d H:i:s'))-strtotime(filectime($filepath_ip)) > 30) )
    {
        file_put_contents($filepath_ip, $ip_client);
    }
    else
    {
        $ip_cli_in_file = file_get_contents($filepath_ip);
        if(strval($ip_client) != strval($ip_cli_in_file))
        {
            die("UserErrorSecurity");
        }
    }
    file_put_contents($filepath_coord,  $_GET["x"]. ', '. $_GET["y"] . PHP_EOL , FILE_APPEND);

}

?>